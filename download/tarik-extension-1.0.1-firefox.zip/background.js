// Tarik — integrasi browser (Chrome, Edge, Firefox).
//
// Saat browser mulai mengunduh, download itu dijeda lalu dikirim ke Tarik lewat
// http://127.0.0.1:<port>/download. Bila Tarik menerima, download browser dibatalkan;
// bila Tarik tidak berjalan, download browser dilanjutkan seperti biasa.
//
// Firefox menyediakan `browser.*` (selalu Promise), Chrome/Edge `chrome.*`.
const api = globalThis.browser ?? globalThis.chrome;

const DEFAULTS = { enabled: true, port: 17117, minSizeKB: 0 };
const MENU_ID = "tarik-download";

async function config() {
  return { ...DEFAULTS, ...(await api.storage.local.get(DEFAULTS)) };
}

function base(port) {
  return `http://127.0.0.1:${port}`;
}

async function ping(port) {
  try {
    const r = await fetch(`${base(port)}/ping`, { signal: AbortSignal.timeout(1500) });
    if (!r.ok) return null;
    const j = await r.json();
    return j.app === "tarik" ? j : null;
  } catch {
    return null;
  }
}

// `storeId`: kontainer Firefox (Multi-Account Containers) punya toples cookie sendiri.
async function cookieHeader(url, storeId) {
  try {
    const details = storeId ? { url, storeId } : { url };
    const cookies = await api.cookies.getAll(details);
    return cookies.map((c) => `${c.name}=${c.value}`).join("; ");
  } catch {
    return "";
  }
}

function baseName(path) {
  if (!path) return null;
  const name = path.split(/[\\/]/).pop();
  return name || null;
}

async function sendToTarik(port, item) {
  const payload = {
    url: item.url,
    fileName: item.fileName || null,
    referrer: item.referrer || null,
    cookies: (await cookieHeader(item.url, item.cookieStoreId)) || null,
    userAgent: navigator.userAgent,
    fileSize: item.fileSize > 0 ? item.fileSize : null,
    mime: item.mime || null,
  };
  try {
    const r = await fetch(`${base(port)}/download`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload),
      signal: AbortSignal.timeout(3000),
    });
    // 403 = Tarik berjalan tetapi integrasi browser dimatikan di aplikasi.
    return r.ok ? "ok" : "refused";
  } catch {
    return "offline";
  }
}

async function setOffline(offline) {
  await api.action.setBadgeText({ text: offline ? "!" : "" });
  await api.action.setBadgeBackgroundColor({ color: "#d33" });
  await api.action.setTitle({ title: offline ? api.i18n.getMessage("offline") : "Tarik" });
}

api.downloads.onCreated.addListener(async (item) => {
  const cfg = await config();
  if (!cfg.enabled || item.incognito || item.byExtensionId) return;
  // `finalUrl` hanya ada di Chrome/Edge.
  const url = item.finalUrl || item.url;
  if (!/^https?:/i.test(url) || item.state !== "in_progress") return;
  if (cfg.minSizeKB > 0 && item.totalBytes > 0 && item.totalBytes < cfg.minSizeKB * 1024) return;

  // Jeda dulu supaya browser tidak terus mengunduh selama kita bertanya ke Tarik.
  try {
    await api.downloads.pause(item.id);
  } catch {}
  const result = await sendToTarik(cfg.port, {
    url,
    fileName: baseName(item.filename),
    referrer: item.referrer,
    fileSize: item.totalBytes,
    mime: item.mime,
    cookieStoreId: item.cookieStoreId,
  });
  if (result === "ok") {
    try {
      await api.downloads.cancel(item.id);
      await api.downloads.erase({ id: item.id });
    } catch {}
    await setOffline(false);
  } else {
    try {
      await api.downloads.resume(item.id);
    } catch {}
    await setOffline(result === "offline");
  }
});

// Menu dibuat ulang tiap browser mulai: Firefox tidak selalu menyimpannya untuk
// latar belakang non-persisten, dan `removeAll` mencegah galat "id sudah ada".
async function createMenu() {
  await api.contextMenus.removeAll();
  api.contextMenus.create({
    id: MENU_ID,
    title: api.i18n.getMessage("menuDownload"),
    contexts: ["link", "video", "audio", "image"],
  });
}
api.runtime.onInstalled.addListener(createMenu);
api.runtime.onStartup.addListener(createMenu);

api.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== MENU_ID) return;
  const url = info.linkUrl || info.srcUrl;
  if (!url || !/^https?:/i.test(url)) return;
  const cfg = await config();
  const result = await sendToTarik(cfg.port, {
    url,
    referrer: info.pageUrl || tab?.url,
    cookieStoreId: tab?.cookieStoreId,
  });
  await setOffline(result === "offline");
});

// Dipakai popup.
api.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (msg?.type === "ping") {
    config()
      .then((cfg) => ping(cfg.port))
      .then(async (r) => {
        await setOffline(!r);
        reply(r);
      });
    return true;
  }
});
