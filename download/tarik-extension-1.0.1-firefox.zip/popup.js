const api = globalThis.browser ?? globalThis.chrome;
const DEFAULTS = { enabled: true, port: 17117, minSizeKB: 0 };
const ALL_SITES = { origins: ["<all_urls>"] };
const $ = (id) => document.getElementById(id);
const t = (key, ...subs) => api.i18n.getMessage(key, subs) || key;

// Teks statis dari _locales/<bahasa browser>/messages.json.
document.documentElement.lang = api.i18n.getUILanguage();
for (const el of document.querySelectorAll("[data-i18n]")) {
  el.textContent = t(el.dataset.i18n);
}

async function refresh() {
  const r = await api.runtime.sendMessage({ type: "ping" });
  const off = r && r.capture === false;
  $("dot").className = "dot " + (!r ? "bad" : off ? "warn" : "ok");
  $("state").textContent = !r ? t("offline") : off ? t("captureOff") : t("connected", r.version);
}

// Firefox bisa memasang ekstensi tanpa akses situs (pengguna boleh mencabutnya). Tanpa
// akses itu cookie tidak terbaca, jadi file di balik login gagal diunduh Tarik.
async function checkSiteAccess() {
  let granted = true;
  try {
    granted = await api.permissions.contains(ALL_SITES);
  } catch {}
  $("perm").hidden = granted;
}

async function init() {
  const cfg = { ...DEFAULTS, ...(await api.storage.local.get(DEFAULTS)) };
  $("enabled").checked = cfg.enabled;
  $("port").value = cfg.port;
  $("minSize").value = cfg.minSizeKB;
  $("enabled").addEventListener("change", (e) => api.storage.local.set({ enabled: e.target.checked }));
  $("port").addEventListener("change", async (e) => {
    const port = Math.min(65535, Math.max(1, parseInt(e.target.value, 10) || DEFAULTS.port));
    e.target.value = port;
    await api.storage.local.set({ port });
    refresh();
  });
  $("minSize").addEventListener("change", (e) =>
    api.storage.local.set({ minSizeKB: Math.max(0, parseInt(e.target.value, 10) || 0) })
  );
  // Harus dipanggil langsung dari klik (tanpa await sebelumnya) supaya browser mau bertanya.
  $("grant").addEventListener("click", () => {
    api.permissions.request(ALL_SITES).then(checkSiteAccess, checkSiteAccess);
  });
  refresh();
  checkSiteAccess();
}

init();
